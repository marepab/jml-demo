# atmecs-jml-poc-network

poc to demonstrate how hyperledger fabric blockchain can be used along with chronocle modules to get good collobaration
